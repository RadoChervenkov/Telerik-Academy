/* global define */
define(function () {
    'use strict';

    var people;

    people = [
        {firstName: 'Thomas', lastName: 'Mueller'},
        {firstName: 'Mario', lastName: 'Goetze'},
        {firstName: 'Manuel', lastName: 'Neuer'},
        {firstName: 'Marko', lastName: 'Reus'},
        {firstName: 'Julian', lastName: 'Draxler'},
        {firstName: 'Julian', lastName: 'Neuer'},
    ];

    return people;
});