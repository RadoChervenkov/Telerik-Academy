/* global define */
define(function () {
    'use strict';

    var animals;

    animals = [
        {name: 'Dingo', species: 'Dog', legs: 4},
        {name: 'Ares', species: 'Dog', legs: 4},
        {name: 'Nasty', species: 'Cockroach', legs: 6},
        {name: 'Grose', species: 'Centipede', legs: 100},
        {name: 'Birdy', species: 'Flamingo', legs: 2}
    ];

    return animals;
});